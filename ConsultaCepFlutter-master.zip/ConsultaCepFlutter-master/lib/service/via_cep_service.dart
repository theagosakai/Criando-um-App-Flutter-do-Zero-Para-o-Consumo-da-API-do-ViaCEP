import 'package:correios/model/resul_cep.dart';
import 'package:http/http.dart';

class ViaCepService {
  var client = new Client();

  Future<ResultCep> fetchCep({String cep}) async {
    final response = await client.get('https://viacep.com.br/ws/$cep/json/');
    if (response.statusCode == 200) {
      return ResultCep.fromJson(response.body);
    } else {
      throw Exception('Requisição inválida!');
    }
  }
}
