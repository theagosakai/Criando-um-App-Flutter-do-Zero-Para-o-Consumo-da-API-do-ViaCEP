# Consumindo API Via CEP

Busca Cep Correios.

## Informações do Projeto

Projeto pessoal usado para treinar os conhecimentos adquiridos no curso do Balta.IO
Consumindo API Via Cep

- [APi Utilizada no Projeto](https://viacep.com.br)


